// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class EscapeRoom : ModuleRules
{
	public EscapeRoom(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] {
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore",
			"EnhancedInput",
			"AIModule",
			"StateTreeModule",
			"GameplayStateTreeModule",
			"UMG",
			"Slate"
		});

		PrivateDependencyModuleNames.AddRange(new string[] { });

		PublicIncludePaths.AddRange(new string[] {
			"EscapeRoom",
			"EscapeRoom/Variant_Platforming",
			"EscapeRoom/Variant_Platforming/Animation",
			"EscapeRoom/Variant_Combat",
			"EscapeRoom/Variant_Combat/AI",
			"EscapeRoom/Variant_Combat/Animation",
			"EscapeRoom/Variant_Combat/Gameplay",
			"EscapeRoom/Variant_Combat/Interfaces",
			"EscapeRoom/Variant_Combat/UI",
			"EscapeRoom/Variant_SideScrolling",
			"EscapeRoom/Variant_SideScrolling/AI",
			"EscapeRoom/Variant_SideScrolling/Gameplay",
			"EscapeRoom/Variant_SideScrolling/Interfaces",
			"EscapeRoom/Variant_SideScrolling/UI"
		});

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });

		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
