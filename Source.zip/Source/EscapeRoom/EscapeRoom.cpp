// Copyright Epic Games, Inc. All Rights Reserved.

#include "EscapeRoom.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, EscapeRoom, "EscapeRoom" );

DEFINE_LOG_CATEGORY(LogEscapeRoom)