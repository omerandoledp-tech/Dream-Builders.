// Copyright Epic Games, Inc. All Rights Reserved.

#include "EscapeRoomGameMode.h"

AEscapeRoomGameMode::AEscapeRoomGameMode()
{
	// stub
}
